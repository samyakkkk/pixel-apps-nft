package io.pixelapps.pixel_apps_ntf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
